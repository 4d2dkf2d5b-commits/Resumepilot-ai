'use client';

import Link from 'next/link';
import { ArrowRight, CheckCircle } from 'lucide-react';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center bg-white overflow-hidden pt-16">
      {/* Grid background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0,0,0,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.04) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Corner marks */}
      <div className="absolute top-20 left-6 w-8 h-8 border-t border-l border-ink-300" />
      <div className="absolute top-20 right-6 w-8 h-8 border-t border-r border-ink-300" />

      <div className="relative mx-auto max-w-6xl px-6 py-24 md:py-32 w-full">
        <div className="max-w-4xl">
          {/* Tag */}
          <div className="section-tag mb-8 animate-fade-up opacity-0-init">
            AI Resume Builder · ATS Optimized · 2 Minutes
          </div>

          {/* Headline */}
          <h1
            className="text-5xl md:text-7xl font-bold tracking-tightest leading-[0.95] text-ink-950 mb-6 text-balance animate-fade-up opacity-0-init animate-delay-100"
          >
            Create a Professional
            <br />
            <span className="relative inline-block">
              ATS-Friendly
              <span
                className="absolute -bottom-1 left-0 right-0 h-1 bg-ink-950"
                aria-hidden
              />
            </span>{' '}
            Resume
            <br />
            in 2 Minutes
          </h1>

          {/* Sub */}
          <p className="text-xl md:text-2xl text-ink-500 mb-10 max-w-2xl leading-relaxed animate-fade-up opacity-0-init animate-delay-200">
            Generate a recruiter-ready resume with AI. No design skills required.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-12 animate-fade-up opacity-0-init animate-delay-300">
            <Link
              href="/builder"
              className="btn-primary text-base px-8 py-4 gap-3"
            >
              Build My Resume
              <ArrowRight size={18} />
            </Link>
            <a
              href="#example"
              className="btn-secondary text-base px-8 py-4"
            >
              See Example
            </a>
          </div>

          {/* Trust signals */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8 animate-fade-up opacity-0-init animate-delay-400">
            {[
              'No account required',
              'ATS-optimized output',
              'PDF & Word download',
            ].map((item) => (
              <div key={item} className="flex items-center gap-2 text-sm text-ink-600">
                <CheckCircle size={14} className="text-ink-950 flex-shrink-0" />
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Floating Resume Card */}
        <div className="absolute right-6 top-1/2 -translate-y-1/2 w-72 hidden xl:block">
          <div className="bg-white border border-ink-200 shadow-2xl p-6 relative">
            {/* Corner decoration */}
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-ink-950" />
            
            <div className="text-center mb-4 pb-4 border-b border-ink-200">
              <div className="text-base font-bold text-ink-900">Alex Morgan</div>
              <div className="text-xs text-ink-500 uppercase tracking-widest mt-1">Senior Product Manager</div>
              <div className="text-xs text-ink-400 mt-1">alex@email.com · +1 555 0123</div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-ink-400 border-b border-ink-200 pb-1 mb-1.5">
                  Summary
                </div>
                <div className="text-[9px] text-ink-600 leading-relaxed">
                  Results-driven PM with 8+ years delivering B2B SaaS products. Led cross-functional teams of 20+ to ship features used by 2M+ users.
                </div>
              </div>

              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-ink-400 border-b border-ink-200 pb-1 mb-1.5">
                  Experience
                </div>
                <div className="text-[9px] font-bold text-ink-800">Senior Product Manager</div>
                <div className="text-[9px] text-ink-500">TechCorp Inc. · 2021–Present</div>
                <ul className="mt-1 space-y-0.5 pl-2.5 list-disc">
                  <li className="text-[8.5px] text-ink-600">Increased user retention by 34% through data-driven feature prioritization</li>
                  <li className="text-[8.5px] text-ink-600">Launched 3 major product lines generating $4.2M ARR</li>
                </ul>
              </div>

              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-ink-400 border-b border-ink-200 pb-1 mb-1.5">
                  Skills
                </div>
                <div className="text-[9px] text-ink-600">Product Strategy · Roadmapping · SQL · Figma · Agile · OKRs</div>
              </div>
            </div>

            {/* ATS badge */}
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-ink-950 text-white text-[9px] font-bold uppercase tracking-widest px-3 py-1 whitespace-nowrap">
              ✓ ATS Optimized
            </div>
          </div>
        </div>
      </div>

      {/* Bottom ticker */}
      <div className="absolute bottom-0 left-0 right-0 bg-ink-950 text-white py-3 overflow-hidden">
        <div className="flex gap-12 whitespace-nowrap animate-[scroll_20s_linear_infinite]">
          {Array.from({ length: 4 }).map((_, i) => (
            <span key={i} className="flex gap-12 text-xs uppercase tracking-widest text-ink-400">
              <span>AI-Powered ·</span>
              <span>ATS-Optimized ·</span>
              <span>Recruiter-Approved ·</span>
              <span>PDF & Word ·</span>
              <span>2-Minute Build ·</span>
              <span>GPT-4o Enhanced ·</span>
            </span>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
}
