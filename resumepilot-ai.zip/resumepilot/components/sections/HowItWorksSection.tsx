import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const steps = [
  {
    step: '01',
    title: 'Fill in your details',
    description:
      'Enter your work history, education, skills, and target job title. Takes about 5 minutes. No formatting needed — just raw information.',
  },
  {
    step: '02',
    title: 'AI rewrites everything',
    description:
      'GPT-4o analyzes your experience and rewrites every bullet point with strong action verbs, quantified results, and ATS-friendly language.',
  },
  {
    step: '03',
    title: 'Preview your resume',
    description:
      'Instantly see your professionally formatted resume. Review the AI-enhanced content and make sure everything looks exactly right.',
  },
  {
    step: '04',
    title: 'Pay once, own it forever',
    description:
      'One payment of €19 unlocks your PDF and Word downloads. No subscription, no hidden fees. Emailed to you immediately.',
  },
];

export default function HowItWorksSection() {
  return (
    <section
      id="how-it-works"
      className="py-24 md:py-32 bg-ink-950 text-white"
    >
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <div className="mb-16">
          <div className="inline-block text-xs font-medium uppercase tracking-[0.15em] text-ink-400 border border-ink-700 px-3 py-1.5 mb-6">
            How It Works
          </div>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight max-w-xl leading-tight">
            From blank page to polished resume in 4 steps
          </h2>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0 border border-ink-800">
          {steps.map((step, i) => (
            <div
              key={step.step}
              className={`p-8 ${i < steps.length - 1 ? 'border-b md:border-b-0 md:border-r border-ink-800' : ''} group hover:bg-ink-900 transition-colors`}
            >
              <div className="text-5xl font-bold text-ink-800 group-hover:text-ink-700 transition-colors mb-8 font-mono">
                {step.step}
              </div>
              <h3 className="text-base font-bold text-white mb-3">
                {step.title}
              </h3>
              <p className="text-sm text-ink-400 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 border-t border-ink-800 pt-12">
          <p className="text-ink-400 max-w-md">
            Most users complete their resume in under 8 minutes, including
            review time.
          </p>
          <Link
            href="/builder"
            className="inline-flex items-center gap-3 bg-white text-ink-950 px-8 py-4 text-sm font-medium hover:bg-ink-100 transition-colors"
          >
            Start Building Now
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
