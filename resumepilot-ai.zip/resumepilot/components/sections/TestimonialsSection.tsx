const testimonials = [
  {
    quote:
      "I'd been struggling to get callbacks for 3 months. After using ResumePilot AI, I had 4 interview invitations within 2 weeks. The AI completely transformed how my experience reads.",
    name: 'Mariana K.',
    role: 'Marketing Manager → Senior Marketing Director',
    initials: 'MK',
  },
  {
    quote:
      "As a career changer, I didn't know how to frame my skills. ResumePilot AI translated my teaching experience into corporate language perfectly. Got hired at a Fortune 500.",
    name: 'David T.',
    role: 'Teacher → Learning & Development Manager',
    initials: 'DT',
  },
  {
    quote:
      'The ATS optimization is real. My previous resume was getting filtered out before anyone read it. Within a week of using this, I was getting responses from Google and Meta.',
    name: 'Priya S.',
    role: 'Software Engineer',
    initials: 'PS',
  },
  {
    quote:
      "I was skeptical about AI-generated content, but this was genuinely impressive. It kept my voice while making everything sharper and more impactful. Worth every cent.",
    name: 'James O.',
    role: 'Product Manager → VP of Product',
    initials: 'JO',
  },
  {
    quote:
      'Just graduated and had almost nothing on my resume. ResumePilot AI helped me frame my projects and internships in a way that actually competed with experienced candidates.',
    name: 'Sofia R.',
    role: 'Recent Graduate → Junior Data Analyst',
    initials: 'SR',
  },
  {
    quote:
      "Used it for my executive resume and was impressed by the strategic framing. The AI understood the difference between a junior resume and a C-suite one. Outstanding quality.",
    name: 'Michael B.',
    role: 'Director → Chief Operations Officer',
    initials: 'MB',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-24 md:py-32 bg-white border-t border-ink-100">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <div className="mb-16">
          <div className="section-tag mb-6">Testimonials</div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-ink-950 max-w-lg leading-tight">
              People who got
              <br />
              the job
            </h2>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-ink-950 tracking-tight">
                  94%
                </div>
                <div className="text-xs text-ink-500 uppercase tracking-wider mt-1">
                  Interview rate
                </div>
              </div>
              <div className="w-px h-12 bg-ink-200" />
              <div className="text-center">
                <div className="text-3xl font-bold text-ink-950 tracking-tight">
                  2min
                </div>
                <div className="text-xs text-ink-500 uppercase tracking-wider mt-1">
                  Average build time
                </div>
              </div>
              <div className="w-px h-12 bg-ink-200" />
              <div className="text-center">
                <div className="text-3xl font-bold text-ink-950 tracking-tight">
                  12k+
                </div>
                <div className="text-xs text-ink-500 uppercase tracking-wider mt-1">
                  Resumes created
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-ink-200">
          {testimonials.map((t) => (
            <div key={t.name} className="bg-white p-8">
              {/* Stars */}
              <div className="flex gap-0.5 mb-5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className="text-ink-950 text-sm">
                    ★
                  </span>
                ))}
              </div>

              <blockquote className="text-sm text-ink-700 leading-relaxed mb-6">
                "{t.quote}"
              </blockquote>

              <div className="flex items-center gap-3 pt-4 border-t border-ink-100">
                <div className="w-9 h-9 bg-ink-950 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {t.initials}
                </div>
                <div>
                  <div className="text-sm font-bold text-ink-900">{t.name}</div>
                  <div className="text-xs text-ink-500">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
