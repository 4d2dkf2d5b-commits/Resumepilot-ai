'use client';

import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    q: 'What makes this ATS-optimized?',
    a: 'Our AI formats your resume using clean, parseable structure — no tables, no graphics, no text boxes that break ATS parsing. We also include industry-specific keywords relevant to your target role and use standard section headers that ATS systems recognize.',
  },
  {
    q: 'How is the AI content different from just ChatGPT?',
    a: 'We use a specialized prompt system trained specifically for resume writing — not general content. The AI focuses on action verbs, quantified achievements, and role-specific language. It also structures the output in exactly the right format, something general ChatGPT doesn\'t do consistently.',
  },
  {
    q: 'Can I edit the resume after it\'s generated?',
    a: 'Yes. You receive a Word (.docx) download that you can open in Microsoft Word, Google Docs, or any compatible editor. Make any tweaks you want before submitting.',
  },
  {
    q: 'What if I don\'t have much work experience?',
    a: "The AI handles entry-level resumes well. For recent graduates or career changers, it emphasizes transferable skills, academic projects, internships, and achievements — framing limited experience in the most compelling way possible.",
  },
  {
    q: 'Is my data safe?',
    a: 'Your resume data is sent to OpenAI for processing (subject to their privacy policy) and is not stored on our servers. We don\'t sell or share your personal information. Payment is processed entirely by Stripe — we never see your card details.',
  },
  {
    q: 'What format is the PDF?',
    a: 'The PDF is a clean, single-column professional format optimized for both ATS systems and human readers. No colors, no graphics — just clean typography and well-organized content.',
  },
  {
    q: 'Can I use it for multiple jobs?',
    a: 'Each purchase generates one resume. If you\'re applying to different industries or roles, we recommend creating a separate resume for each, as tailoring to the specific role increases interview rates significantly.',
  },
  {
    q: 'What if I\'m not happy with the result?',
    a: 'We offer a full refund within 48 hours if your AI-generated resume isn\'t significantly better than your input. Email us and we\'ll process it immediately, no questions asked.',
  },
];

export default function FAQSection() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 md:py-32 bg-white border-t border-ink-100">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          {/* Left */}
          <div>
            <div className="section-tag mb-6">FAQ</div>
            <h2 className="text-4xl font-bold tracking-tight text-ink-950 mb-4 leading-tight">
              Common questions
            </h2>
            <p className="text-ink-500 text-sm leading-relaxed">
              Everything you need to know before building your resume. Still
              have a question?{' '}
              <a
                href="mailto:hello@resumepilot.ai"
                className="text-ink-900 underline underline-offset-4"
              >
                Email us
              </a>
              .
            </p>
          </div>

          {/* Right: accordion */}
          <div className="lg:col-span-2 space-y-0 border-t border-ink-200">
            {faqs.map((faq, i) => (
              <div key={i} className="border-b border-ink-200">
                <button
                  className="w-full flex items-start justify-between gap-4 py-5 text-left"
                  onClick={() => setOpen(open === i ? null : i)}
                >
                  <span className="text-sm font-medium text-ink-900">
                    {faq.q}
                  </span>
                  <div className="flex-shrink-0 mt-0.5">
                    {open === i ? (
                      <Minus size={16} className="text-ink-500" />
                    ) : (
                      <Plus size={16} className="text-ink-500" />
                    )}
                  </div>
                </button>
                {open === i && (
                  <div className="pb-5 text-sm text-ink-600 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
