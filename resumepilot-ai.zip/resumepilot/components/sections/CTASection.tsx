import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-24 md:py-32 bg-ink-950 border-t border-ink-800">
      <div className="mx-auto max-w-6xl px-6 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="inline-block text-xs font-medium uppercase tracking-[0.15em] text-ink-500 border border-ink-700 px-3 py-1.5 mb-8">
            Get Started Today
          </div>
          <h2 className="text-4xl md:text-6xl font-bold tracking-tightest text-white mb-6 leading-tight">
            Your next job starts
            <br />
            with a better resume.
          </h2>
          <p className="text-ink-400 text-lg mb-10 leading-relaxed">
            Stop losing opportunities to resumes that don't pass ATS filters.
            Build a professional, recruiter-ready resume in 2 minutes.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/builder"
              className="inline-flex items-center gap-2 bg-white text-ink-950 px-8 py-4 text-sm font-medium hover:bg-ink-100 transition-colors"
            >
              Build My Resume — €19
              <ArrowRight size={16} />
            </Link>
            <span className="text-ink-600 text-sm">One-time payment · No subscription</span>
          </div>
        </div>
      </div>
    </section>
  );
}
