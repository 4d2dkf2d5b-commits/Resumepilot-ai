import Link from 'next/link';
import { Check, ArrowRight } from 'lucide-react';

const features = [
  'AI rewrite with GPT-4o',
  'ATS-optimization pass',
  'Professional summary',
  'Bullet point enhancement',
  'PDF download',
  'Word (.docx) download',
  'Emailed to you instantly',
  'No subscription required',
];

export default function PricingSection() {
  return (
    <section id="pricing" className="py-24 md:py-32 bg-ink-50 border-t border-ink-100">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="section-tag mb-6">Pricing</div>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-ink-950 mb-4">
            One price. One great resume.
          </h2>
          <p className="text-ink-500 max-w-md mx-auto">
            No monthly fees. No surprise charges. Pay once and own your
            professional resume forever.
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-5 gap-px bg-ink-200">
          {/* Price card */}
          <div className="md:col-span-2 bg-ink-950 text-white p-10 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold uppercase tracking-widest text-ink-400 mb-6">
                Basic Plan
              </div>
              <div className="flex items-start gap-1 mb-2">
                <span className="text-2xl font-bold mt-2 text-ink-300">€</span>
                <span className="text-7xl font-bold tracking-tight leading-none">
                  19
                </span>
              </div>
              <div className="text-ink-400 text-sm">One-time payment</div>
            </div>

            <div className="mt-10">
              <Link
                href="/builder"
                className="w-full inline-flex items-center justify-center gap-2 bg-white text-ink-950 px-6 py-4 text-sm font-medium hover:bg-ink-100 transition-colors"
              >
                Build My Resume
                <ArrowRight size={16} />
              </Link>
              <p className="text-ink-600 text-xs text-center mt-3">
                Secure payment via Stripe
              </p>
            </div>
          </div>

          {/* Features list */}
          <div className="md:col-span-3 bg-white p-10">
            <div className="text-xs font-semibold uppercase tracking-widest text-ink-400 mb-6">
              Everything included
            </div>
            <ul className="space-y-4">
              {features.map((feature) => (
                <li key={feature} className="flex items-center gap-3">
                  <div className="w-5 h-5 bg-ink-950 flex items-center justify-center flex-shrink-0">
                    <Check size={12} className="text-white" strokeWidth={3} />
                  </div>
                  <span className="text-sm text-ink-700">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-8 border-t border-ink-100">
              <div className="flex items-start gap-3">
                <div className="w-5 h-5 bg-ink-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-ink-500 text-xs">?</span>
                </div>
                <p className="text-xs text-ink-400 leading-relaxed">
                  Not satisfied? We offer a full refund if your resume isn't significantly
                  better than what you entered. Just email us within 48 hours.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Trust badges */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-8 text-ink-500">
          {[
            '🔒 256-bit SSL encryption',
            '💳 Powered by Stripe',
            '📧 Instant email delivery',
            '↩️ 48h refund policy',
          ].map((badge) => (
            <span key={badge} className="text-sm">
              {badge}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
