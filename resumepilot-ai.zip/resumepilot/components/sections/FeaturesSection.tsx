import { Zap, Target, FileText, Download, Shield, Clock } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'GPT-4o AI Engine',
    description:
      'Powered by OpenAI\'s most capable model. Every word is rewritten with strong action verbs, quantified achievements, and professional language.',
  },
  {
    icon: Target,
    title: 'ATS-Pass Guaranteed',
    description:
      'Formatted and structured to pass Applicant Tracking Systems. No fancy graphics that break parsing — clean, readable, machine-friendly.',
  },
  {
    icon: FileText,
    title: 'PDF & Word Formats',
    description:
      'Download your resume as a polished PDF or an editable Word document. Use the PDF for applications, Word for quick tweaks.',
  },
  {
    icon: Download,
    title: 'Instant Generation',
    description:
      'Fill in your details, click Generate. Your professional resume is ready in seconds — no waiting, no queue, no design work.',
  },
  {
    icon: Shield,
    title: 'Private & Secure',
    description:
      'Your data is never stored or sold. Each resume is generated in real-time and delivered directly to you. Zero data retention.',
  },
  {
    icon: Clock,
    title: 'Built for 2025 Job Market',
    description:
      'Modern resume conventions, current keywords, and formatting that matches what hiring managers at top companies expect today.',
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 md:py-32 bg-white border-t border-ink-100">
      <div className="mx-auto max-w-6xl px-6">
        {/* Header */}
        <div className="mb-16">
          <div className="section-tag mb-6">Why ResumePilot</div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-ink-950 max-w-lg leading-tight">
              Everything a recruiter
              <br />
              wants to see
            </h2>
            <p className="text-ink-500 max-w-sm leading-relaxed md:text-right">
              We've analyzed thousands of job postings and resumes to build the
              most effective AI resume tool available.
            </p>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-ink-200">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="bg-white p-8 group hover:bg-ink-950 transition-colors duration-200"
              >
                <div className="mb-5">
                  <div className="w-10 h-10 border border-ink-200 group-hover:border-white/20 flex items-center justify-center transition-colors">
                    <Icon
                      size={18}
                      className="text-ink-700 group-hover:text-white transition-colors"
                    />
                  </div>
                </div>
                <h3 className="text-base font-bold text-ink-900 group-hover:text-white mb-3 transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-ink-500 group-hover:text-ink-300 leading-relaxed transition-colors">
                  {feature.description}
                </p>
                <div className="mt-6 text-xs font-medium text-ink-300 group-hover:text-ink-500 tabular-nums transition-colors">
                  0{i + 1}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
