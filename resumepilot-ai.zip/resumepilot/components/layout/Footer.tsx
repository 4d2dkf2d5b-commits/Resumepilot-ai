import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-ink-950 text-ink-400">
      <div className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 font-bold text-lg text-white mb-4">
              <span className="inline-block w-6 h-6 bg-white text-ink-950 text-xs font-bold flex items-center justify-center">
                RP
              </span>
              ResumePilot AI
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              AI-powered resume builder that creates ATS-optimized, recruiter-ready resumes in under 2 minutes.
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-white text-xs font-semibold uppercase tracking-widest mb-4">
              Product
            </h3>
            <ul className="space-y-3 text-sm">
              <li>
                <Link href="/builder" className="hover:text-white transition-colors">
                  Build Resume
                </Link>
              </li>
              <li>
                <Link href="#pricing" className="hover:text-white transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="#features" className="hover:text-white transition-colors">
                  Features
                </Link>
              </li>
              <li>
                <Link href="#faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white text-xs font-semibold uppercase tracking-widest mb-4">
              Legal
            </h3>
            <ul className="space-y-3 text-sm">
              <li>
                <Link href="/privacy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/refund" className="hover:text-white transition-colors">
                  Refund Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-ink-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ink-600">
            © {new Date().getFullYear()} ResumePilot AI. All rights reserved.
          </p>
          <div className="flex items-center gap-2">
            <span className="text-xs text-ink-600">Powered by</span>
            <span className="text-xs text-ink-500 font-medium">GPT-4o · Stripe · Next.js</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
