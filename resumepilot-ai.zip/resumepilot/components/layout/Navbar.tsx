'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white border-b border-ink-200' : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto max-w-6xl px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-2 font-bold text-lg tracking-tight text-ink-950"
        >
          <span className="inline-block w-6 h-6 bg-ink-950 text-white text-xs font-bold flex items-center justify-center leading-none">
            RP
          </span>
          ResumePilot AI
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <Link
            href="#features"
            className="text-sm text-ink-600 hover:text-ink-900 transition-colors"
          >
            Features
          </Link>
          <Link
            href="#how-it-works"
            className="text-sm text-ink-600 hover:text-ink-900 transition-colors"
          >
            How it works
          </Link>
          <Link
            href="#pricing"
            className="text-sm text-ink-600 hover:text-ink-900 transition-colors"
          >
            Pricing
          </Link>
          <Link href="/builder" className="btn-primary text-sm px-5 py-2.5">
            Build My Resume
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 text-ink-700"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-b border-ink-200 px-6 py-4 flex flex-col gap-4">
          <Link
            href="#features"
            className="text-sm text-ink-700"
            onClick={() => setMobileOpen(false)}
          >
            Features
          </Link>
          <Link
            href="#how-it-works"
            className="text-sm text-ink-700"
            onClick={() => setMobileOpen(false)}
          >
            How it works
          </Link>
          <Link
            href="#pricing"
            className="text-sm text-ink-700"
            onClick={() => setMobileOpen(false)}
          >
            Pricing
          </Link>
          <Link
            href="/builder"
            className="btn-primary text-center text-sm"
            onClick={() => setMobileOpen(false)}
          >
            Build My Resume
          </Link>
        </div>
      )}
    </header>
  );
}
