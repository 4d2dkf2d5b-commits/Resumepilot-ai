import { UseFormReturn, UseFieldArrayReturn } from 'react-hook-form';
import { ResumeFormData } from '@/lib/types';
import { Plus, Trash2 } from 'lucide-react';

interface Props {
  form: UseFormReturn<ResumeFormData>;
  certFieldArray: UseFieldArrayReturn<ResumeFormData, 'certifications'>;
}

export default function SkillsStep({ form, certFieldArray }: Props) {
  const { register } = form;
  const { fields, append, remove } = certFieldArray;

  return (
    <div className="space-y-6">
      {/* Skills */}
      <div>
        <label className="label">Skills</label>
        <textarea
          {...register('skills')}
          className="input-field min-h-[100px] resize-y"
          placeholder="Python, SQL, Figma, Agile, Project Management, Data Analysis, React, Node.js..."
        />
        <p className="text-xs text-ink-400 mt-1.5">
          Separate with commas. The AI will organize and enhance these.
        </p>
      </div>

      {/* Languages */}
      <div>
        <label className="label">Languages</label>
        <input
          {...register('languages')}
          className="input-field"
          placeholder="English (Native), Spanish (Fluent), French (Intermediate)"
        />
      </div>

      {/* Certifications */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="label mb-0">Certifications</label>
          <button
            type="button"
            onClick={() => append({ name: '', issuer: '', year: '' })}
            className="text-xs text-ink-500 hover:text-ink-900 flex items-center gap-1 transition-colors"
          >
            <Plus size={13} />
            Add
          </button>
        </div>

        {fields.length === 0 ? (
          <button
            type="button"
            onClick={() => append({ name: '', issuer: '', year: '' })}
            className="w-full border border-dashed border-ink-300 py-4 text-sm text-ink-400 hover:border-ink-500 hover:text-ink-600 transition-colors flex items-center justify-center gap-2"
          >
            <Plus size={15} />
            Add Certification (optional)
          </button>
        ) : (
          <div className="space-y-3">
            {fields.map((field, index) => (
              <div key={field.id} className="border border-ink-200 p-4 relative">
                <button
                  type="button"
                  onClick={() => remove(index)}
                  className="absolute top-3 right-3 text-ink-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={14} />
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pr-6">
                  <div className="sm:col-span-2">
                    <label className="label text-[10px]">Certification Name</label>
                    <input
                      {...register(`certifications.${index}.name`)}
                      className="input-field py-2 text-sm"
                      placeholder="AWS Solutions Architect"
                    />
                  </div>
                  <div>
                    <label className="label text-[10px]">Year</label>
                    <input
                      {...register(`certifications.${index}.year`)}
                      className="input-field py-2 text-sm"
                      placeholder="2024"
                    />
                  </div>
                  <div className="sm:col-span-3">
                    <label className="label text-[10px]">Issuing Organization</label>
                    <input
                      {...register(`certifications.${index}.issuer`)}
                      className="input-field py-2 text-sm"
                      placeholder="Amazon Web Services"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Final hint */}
      <div className="bg-ink-50 border border-ink-200 p-4">
        <p className="text-xs text-ink-600 leading-relaxed">
          <strong className="text-ink-800">You're almost done.</strong> Click{' '}
          <strong className="text-ink-800">Generate My Resume</strong> and our AI
          will professionally rewrite everything — strong action verbs, quantified
          achievements, ATS-optimized language. Takes about 10 seconds.
        </p>
      </div>
    </div>
  );
}
