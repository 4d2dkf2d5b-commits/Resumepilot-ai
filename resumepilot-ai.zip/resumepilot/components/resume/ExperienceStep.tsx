import { UseFormReturn, UseFieldArrayReturn } from 'react-hook-form';
import { ResumeFormData } from '@/lib/types';
import { Plus, Trash2 } from 'lucide-react';

interface Props {
  form: UseFormReturn<ResumeFormData>;
  fieldArray: UseFieldArrayReturn<ResumeFormData, 'workExperience'>;
}

export default function ExperienceStep({ form, fieldArray }: Props) {
  const { register, watch } = form;
  const { fields, append, remove } = fieldArray;

  return (
    <div className="space-y-6">
      {fields.map((field, index) => {
        const isCurrent = watch(`workExperience.${index}.current`);
        return (
          <div
            key={field.id}
            className="border border-ink-200 p-5 relative"
          >
            {fields.length > 1 && (
              <button
                type="button"
                onClick={() => remove(index)}
                className="absolute top-4 right-4 text-ink-400 hover:text-red-500 transition-colors"
                title="Remove"
              >
                <Trash2 size={15} />
              </button>
            )}

            <div className="text-xs font-semibold uppercase tracking-widest text-ink-400 mb-4">
              Position {index + 1}
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label">Company Name</label>
                  <input
                    {...register(`workExperience.${index}.company`)}
                    className="input-field"
                    placeholder="Acme Corporation"
                  />
                </div>
                <div>
                  <label className="label">Job Title</label>
                  <input
                    {...register(`workExperience.${index}.title`)}
                    className="input-field"
                    placeholder="Senior Product Manager"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Start Date</label>
                  <input
                    {...register(`workExperience.${index}.startDate`)}
                    className="input-field"
                    placeholder="Jan 2022"
                  />
                </div>
                <div>
                  <label className="label">End Date</label>
                  <input
                    {...register(`workExperience.${index}.endDate`)}
                    className="input-field"
                    placeholder="Dec 2024"
                    disabled={isCurrent}
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  {...register(`workExperience.${index}.current`)}
                  className="w-4 h-4 accent-ink-950"
                />
                <span className="text-sm text-ink-700">
                  I currently work here
                </span>
              </label>

              <div>
                <label className="label">Responsibilities & Achievements</label>
                <textarea
                  {...register(`workExperience.${index}.description`)}
                  className="input-field min-h-[120px] resize-y"
                  placeholder="Describe what you did, your key responsibilities, and any achievements. Don't worry about formatting — write naturally. The AI will rewrite this professionally with action verbs and metrics."
                />
                <p className="text-xs text-ink-400 mt-1.5">
                  Include any numbers, percentages, or results — AI will highlight them.
                </p>
              </div>
            </div>
          </div>
        );
      })}

      <button
        type="button"
        onClick={() =>
          append({
            company: '',
            title: '',
            startDate: '',
            endDate: '',
            current: false,
            description: '',
          })
        }
        className="w-full border border-dashed border-ink-300 py-3 text-sm text-ink-500 hover:border-ink-600 hover:text-ink-700 transition-colors flex items-center justify-center gap-2"
      >
        <Plus size={15} />
        Add Another Position
      </button>
    </div>
  );
}
