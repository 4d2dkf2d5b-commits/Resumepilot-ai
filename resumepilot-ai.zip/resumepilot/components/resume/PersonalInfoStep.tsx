import { UseFormReturn } from 'react-hook-form';
import { ResumeFormData } from '@/lib/types';

interface Props {
  form: UseFormReturn<ResumeFormData>;
}

export default function PersonalInfoStep({ form }: Props) {
  const { register, formState: { errors } } = form;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="label">Full Name *</label>
          <input
            {...register('fullName', { required: 'Full name is required' })}
            className="input-field"
            placeholder="Alex Morgan"
          />
          {errors.fullName && (
            <p className="text-red-500 text-xs mt-1">{errors.fullName.message}</p>
          )}
        </div>

        <div>
          <label className="label">Email *</label>
          <input
            {...register('email', {
              required: 'Email is required',
              pattern: { value: /^\S+@\S+$/i, message: 'Invalid email' },
            })}
            type="email"
            className="input-field"
            placeholder="alex@email.com"
          />
          {errors.email && (
            <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="label">Phone</label>
          <input
            {...register('phone')}
            type="tel"
            className="input-field"
            placeholder="+1 (555) 000-0000"
          />
        </div>

        <div>
          <label className="label">Location</label>
          <input
            {...register('address')}
            className="input-field"
            placeholder="New York, NY"
          />
        </div>
      </div>

      <div>
        <label className="label">Target Job Title *</label>
        <input
          {...register('targetJobTitle', { required: 'Target job title is required' })}
          className="input-field"
          placeholder="Senior Product Manager"
        />
        {errors.targetJobTitle && (
          <p className="text-red-500 text-xs mt-1">{errors.targetJobTitle.message}</p>
        )}
        <p className="text-xs text-ink-400 mt-1.5">
          The AI will tailor your resume to this specific role.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="label">LinkedIn URL</label>
          <input
            {...register('linkedIn')}
            className="input-field"
            placeholder="linkedin.com/in/alexmorgan"
          />
        </div>

        <div>
          <label className="label">Website / Portfolio</label>
          <input
            {...register('website')}
            className="input-field"
            placeholder="alexmorgan.com"
          />
        </div>
      </div>

      <div>
        <label className="label">Professional Summary (optional)</label>
        <textarea
          {...register('professionalSummary')}
          className="input-field min-h-[100px] resize-y"
          placeholder="Brief overview of your background and career goals. The AI will enhance this — a rough version is fine."
        />
        <p className="text-xs text-ink-400 mt-1.5">
          Leave blank and the AI will write one based on your experience.
        </p>
      </div>
    </div>
  );
}
