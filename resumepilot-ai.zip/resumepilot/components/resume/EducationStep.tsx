import { UseFormReturn, UseFieldArrayReturn } from 'react-hook-form';
import { ResumeFormData } from '@/lib/types';
import { Plus, Trash2 } from 'lucide-react';

interface Props {
  form: UseFormReturn<ResumeFormData>;
  fieldArray: UseFieldArrayReturn<ResumeFormData, 'education'>;
}

export default function EducationStep({ form, fieldArray }: Props) {
  const { register } = form;
  const { fields, append, remove } = fieldArray;

  return (
    <div className="space-y-6">
      {fields.map((field, index) => (
        <div key={field.id} className="border border-ink-200 p-5 relative">
          {fields.length > 1 && (
            <button
              type="button"
              onClick={() => remove(index)}
              className="absolute top-4 right-4 text-ink-400 hover:text-red-500 transition-colors"
              title="Remove"
            >
              <Trash2 size={15} />
            </button>
          )}

          <div className="text-xs font-semibold uppercase tracking-widest text-ink-400 mb-4">
            Education {index + 1}
          </div>

          <div className="space-y-4">
            <div>
              <label className="label">Institution</label>
              <input
                {...register(`education.${index}.institution`)}
                className="input-field"
                placeholder="Harvard University"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">Degree</label>
                <input
                  {...register(`education.${index}.degree`)}
                  className="input-field"
                  placeholder="Bachelor of Science"
                />
              </div>
              <div>
                <label className="label">Field of Study</label>
                <input
                  {...register(`education.${index}.field`)}
                  className="input-field"
                  placeholder="Computer Science"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Start Year</label>
                <input
                  {...register(`education.${index}.startDate`)}
                  className="input-field"
                  placeholder="2018"
                />
              </div>
              <div>
                <label className="label">End Year</label>
                <input
                  {...register(`education.${index}.endDate`)}
                  className="input-field"
                  placeholder="2022"
                />
              </div>
            </div>

            <div>
              <label className="label">GPA (optional)</label>
              <input
                {...register(`education.${index}.gpa`)}
                className="input-field"
                placeholder="3.8"
              />
            </div>
          </div>
        </div>
      ))}

      <button
        type="button"
        onClick={() =>
          append({
            institution: '',
            degree: '',
            field: '',
            startDate: '',
            endDate: '',
            gpa: '',
          })
        }
        className="w-full border border-dashed border-ink-300 py-3 text-sm text-ink-500 hover:border-ink-600 hover:text-ink-700 transition-colors flex items-center justify-center gap-2"
      >
        <Plus size={15} />
        Add Another School
      </button>
    </div>
  );
}
