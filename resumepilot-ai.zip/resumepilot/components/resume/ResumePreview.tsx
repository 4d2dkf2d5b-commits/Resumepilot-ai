'use client';

import { GeneratedResume } from '@/lib/types';
import { Lock } from 'lucide-react';

interface Props {
  resume: GeneratedResume;
  locked: boolean;
  onUnlock?: () => void;
}

export default function ResumePreview({ resume, locked, onUnlock }: Props) {
  return (
    <div className="relative">
      {/* Resume paper */}
      <div
        className={`bg-white border border-ink-200 shadow-lg mx-auto transition-all duration-300 ${
          locked ? 'select-none' : ''
        }`}
        style={{ maxWidth: '816px', fontFamily: "'Times New Roman', Georgia, serif" }}
      >
        {/* Actual resume content */}
        <div className="p-[50px]" id="resume-content">
          {/* Header */}
          <div className="text-center mb-5 pb-4 border-b-2 border-gray-900">
            <h1
              style={{
                fontSize: '22pt',
                fontWeight: 700,
                letterSpacing: '-0.02em',
                lineHeight: 1.1,
                marginBottom: '4px',
              }}
            >
              {resume.fullName}
            </h1>
            <div
              style={{
                fontSize: '9.5pt',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                color: '#444',
                fontFamily: 'Arial, sans-serif',
                marginBottom: '6px',
              }}
            >
              {resume.targetJobTitle}
            </div>
            <div
              style={{
                fontSize: '9.5pt',
                color: '#666',
                fontFamily: 'Arial, sans-serif',
              }}
            >
              {[
                resume.email,
                resume.phone,
                resume.address,
                resume.linkedIn,
                resume.website,
              ]
                .filter(Boolean)
                .join(' · ')}
            </div>
          </div>

          {/* Summary */}
          {resume.professionalSummary && (
            <div className="mb-1">
              <SectionHeader>Professional Summary</SectionHeader>
              <p style={{ fontSize: '10.5pt', lineHeight: 1.5, color: '#1a1a1a' }}>
                {resume.professionalSummary}
              </p>
            </div>
          )}

          {/* Experience */}
          {resume.workExperience.length > 0 && (
            <div>
              <SectionHeader>Work Experience</SectionHeader>
              {resume.workExperience.map((job, i) => (
                <div key={i} style={{ marginBottom: '14px' }}>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'baseline',
                      flexWrap: 'wrap',
                      gap: '4px',
                    }}
                  >
                    <div>
                      <span
                        style={{
                          fontWeight: 700,
                          fontSize: '11pt',
                          color: '#1a1a1a',
                        }}
                      >
                        {job.title}
                      </span>
                      <span style={{ color: '#444', fontSize: '11pt' }}>
                        {' '}
                        — {job.company}
                      </span>
                    </div>
                    <span
                      style={{
                        fontSize: '9.5pt',
                        color: '#666',
                        whiteSpace: 'nowrap',
                        fontFamily: 'Arial, sans-serif',
                      }}
                    >
                      {job.startDate} – {job.current ? 'Present' : job.endDate}
                    </span>
                  </div>
                  <ul
                    style={{
                      margin: '5px 0 0 0',
                      paddingLeft: '18px',
                      listStyleType: 'disc',
                    }}
                  >
                    {job.bullets.map((bullet, j) => (
                      <li
                        key={j}
                        style={{
                          fontSize: '10.5pt',
                          marginBottom: '3px',
                          color: '#1a1a1a',
                          lineHeight: 1.45,
                        }}
                      >
                        {bullet}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {/* Education */}
          {resume.education.length > 0 && (
            <div>
              <SectionHeader>Education</SectionHeader>
              {resume.education.map((edu, i) => (
                <div key={i} style={{ marginBottom: '10px' }}>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'baseline',
                      flexWrap: 'wrap',
                      gap: '4px',
                    }}
                  >
                    <div>
                      <span
                        style={{ fontWeight: 700, fontSize: '11pt', color: '#1a1a1a' }}
                      >
                        {edu.degree}
                        {edu.field ? ` in ${edu.field}` : ''}
                      </span>
                      <span style={{ color: '#444' }}> — {edu.institution}</span>
                    </div>
                    <span
                      style={{
                        fontSize: '9.5pt',
                        color: '#666',
                        fontFamily: 'Arial, sans-serif',
                      }}
                    >
                      {edu.startDate} – {edu.endDate}
                    </span>
                  </div>
                  {edu.gpa && (
                    <div style={{ fontSize: '10pt', color: '#555', marginTop: '2px' }}>
                      GPA: {edu.gpa}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Skills */}
          {resume.skills.length > 0 && (
            <div>
              <SectionHeader>Skills</SectionHeader>
              <p style={{ fontSize: '10.5pt', color: '#1a1a1a', lineHeight: 1.5 }}>
                {resume.skills.join(' · ')}
              </p>
            </div>
          )}

          {/* Languages */}
          {resume.languages.length > 0 && (
            <div>
              <SectionHeader>Languages</SectionHeader>
              <p style={{ fontSize: '10.5pt', color: '#1a1a1a' }}>
                {resume.languages.join(' · ')}
              </p>
            </div>
          )}

          {/* Certifications */}
          {resume.certifications.length > 0 && (
            <div>
              <SectionHeader>Certifications</SectionHeader>
              {resume.certifications.map((cert, i) => (
                <div key={i} style={{ fontSize: '10.5pt', marginBottom: '5px', color: '#1a1a1a' }}>
                  <strong>{cert.name}</strong>
                  {cert.issuer ? ` — ${cert.issuer}` : ''}
                  {cert.year ? ` (${cert.year})` : ''}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Blur overlay — bottom half locked */}
        {locked && (
          <div className="absolute bottom-0 left-0 right-0 h-2/5 pointer-events-none">
            <div
              className="absolute inset-0"
              style={{
                background:
                  'linear-gradient(to bottom, transparent 0%, rgba(255,255,255,0.6) 20%, rgba(255,255,255,0.95) 60%, rgba(255,255,255,1) 100%)',
                backdropFilter: 'blur(3px)',
                WebkitBackdropFilter: 'blur(3px)',
              }}
            />
          </div>
        )}
      </div>

      {/* Lock CTA */}
      {locked && (
        <div className="text-center mt-0 relative z-10 -mt-8 pb-6">
          <div className="inline-flex flex-col items-center gap-3 bg-white border border-ink-200 shadow-xl px-8 py-6">
            <div className="w-10 h-10 bg-ink-950 flex items-center justify-center">
              <Lock size={16} className="text-white" />
            </div>
            <div>
              <div className="font-bold text-ink-900 mb-0.5">
                Your resume is ready
              </div>
              <div className="text-sm text-ink-500">
                Pay once to unlock PDF & Word download
              </div>
            </div>
            {onUnlock && (
              <button
                onClick={onUnlock}
                className="btn-primary px-8 py-3 mt-1"
              >
                Unlock & Download — €19
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function SectionHeader({ children }: { children: React.ReactNode }) {
  return (
    <h2
      style={{
        fontSize: '9.5pt',
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.1em',
        borderBottom: '1.5px solid #1a1a1a',
        paddingBottom: '4px',
        marginBottom: '10px',
        marginTop: '16px',
        fontFamily: 'Arial, sans-serif',
        color: '#1a1a1a',
      }}
    >
      {children}
    </h2>
  );
}
