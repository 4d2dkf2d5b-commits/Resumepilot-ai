'use client';

import { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { GeneratedResume, ResumeFormData } from '@/lib/types';
import ResumePreview from '@/components/resume/ResumePreview';
import PersonalInfoStep from '@/components/resume/PersonalInfoStep';
import ExperienceStep from '@/components/resume/ExperienceStep';
import EducationStep from '@/components/resume/EducationStep';
import SkillsStep from '@/components/resume/SkillsStep';
import { ArrowLeft, ArrowRight, Loader2, Sparkles } from 'lucide-react';
import Link from 'next/link';

const STEPS = [
  { id: 'personal', label: 'Personal Info' },
  { id: 'experience', label: 'Experience' },
  { id: 'education', label: 'Education' },
  { id: 'skills', label: 'Skills & More' },
];

export default function BuilderPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedResume, setGeneratedResume] = useState<GeneratedResume | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const form = useForm<ResumeFormData>({
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      address: '',
      linkedIn: '',
      website: '',
      targetJobTitle: '',
      professionalSummary: '',
      workExperience: [
        {
          company: '',
          title: '',
          startDate: '',
          endDate: '',
          current: false,
          description: '',
        },
      ],
      education: [
        {
          institution: '',
          degree: '',
          field: '',
          startDate: '',
          endDate: '',
          gpa: '',
        },
      ],
      skills: '',
      languages: '',
      certifications: [],
    },
  });

  const workFieldArray = useFieldArray({
    control: form.control,
    name: 'workExperience',
  });

  const educationFieldArray = useFieldArray({
    control: form.control,
    name: 'education',
  });

  const certFieldArray = useFieldArray({
    control: form.control,
    name: 'certifications',
  });

  const handleGenerate = async () => {
    const data = form.getValues();

    if (!data.fullName || !data.email || !data.targetJobTitle) {
      setError('Please fill in your full name, email, and target job title before generating.');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to generate resume');
      }

      setGeneratedResume(result.resume);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Something went wrong. Please try again.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCheckout = async () => {
    if (!generatedResume) return;
    setIsCheckingOut(true);

    try {
      const response = await fetch('/api/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resumeData: generatedResume,
          customerEmail: generatedResume.email,
          resumeId: `resume_${Date.now()}`,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to create checkout');
      }

      if (result.url) {
        window.location.href = result.url;
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Checkout failed. Please try again.'
      );
      setIsCheckingOut(false);
    }
  };

  const nextStep = () => {
    if (currentStep < STEPS.length - 1) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-ink-200 bg-white sticky top-0 z-40">
        <div className="mx-auto max-w-7xl px-6 h-14 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 font-bold text-base text-ink-950"
          >
            <span className="inline-flex w-6 h-6 bg-ink-950 text-white text-xs font-bold items-center justify-center">
              RP
            </span>
            ResumePilot AI
          </Link>

          {/* Step indicators - desktop */}
          <div className="hidden md:flex items-center gap-1">
            {STEPS.map((step, i) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(i)}
                className={`px-3 py-1 text-xs font-medium transition-colors ${
                  i === currentStep
                    ? 'bg-ink-950 text-white'
                    : i < currentStep
                    ? 'text-ink-500 hover:text-ink-900'
                    : 'text-ink-300'
                }`}
              >
                {step.label}
              </button>
            ))}
          </div>

          <div className="text-xs text-ink-400">
            Step {currentStep + 1} of {STEPS.length}
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-0.5 bg-ink-100">
          <div
            className="h-full bg-ink-950 transition-all duration-300"
            style={{
              width: `${((currentStep + 1) / STEPS.length) * 100}%`,
            }}
          />
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-8">
        {!generatedResume ? (
          /* Form view */
          <div className="max-w-2xl mx-auto">
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-ink-950 mb-1">
                {STEPS[currentStep].label}
              </h1>
              <p className="text-sm text-ink-500">
                {currentStep === 0 && 'Start with your contact information.'}
                {currentStep === 1 && 'Add your work history. The AI will enhance each entry.'}
                {currentStep === 2 && 'Enter your educational background.'}
                {currentStep === 3 && 'List your skills, languages, and certifications.'}
              </p>
            </div>

            {/* Step content */}
            {currentStep === 0 && <PersonalInfoStep form={form} />}
            {currentStep === 1 && (
              <ExperienceStep form={form} fieldArray={workFieldArray} />
            )}
            {currentStep === 2 && (
              <EducationStep form={form} fieldArray={educationFieldArray} />
            )}
            {currentStep === 3 && (
              <SkillsStep form={form} certFieldArray={certFieldArray} />
            )}

            {/* Error */}
            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}

            {/* Navigation */}
            <div className="mt-8 flex items-center justify-between border-t border-ink-100 pt-6">
              <button
                type="button"
                onClick={prevStep}
                disabled={currentStep === 0}
                className="btn-secondary px-5 py-2.5 text-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2"
              >
                <ArrowLeft size={16} />
                Back
              </button>

              {currentStep < STEPS.length - 1 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="btn-primary px-6 py-2.5 text-sm flex items-center gap-2"
                >
                  Next
                  <ArrowRight size={16} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="btn-primary px-6 py-2.5 text-sm flex items-center gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Generating with AI...
                    </>
                  ) : (
                    <>
                      <Sparkles size={16} />
                      Generate My Resume
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        ) : (
          /* Preview view */
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <h1 className="text-xl font-bold text-ink-950">
                  Your resume is ready ✓
                </h1>
                <p className="text-sm text-ink-500 mt-1">
                  Reviewed and enhanced by GPT-4o. Unlock to download.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setGeneratedResume(null);
                    setCurrentStep(3);
                  }}
                  className="btn-secondary text-sm px-4 py-2.5"
                >
                  Edit & Regenerate
                </button>
                <button
                  type="button"
                  onClick={handleCheckout}
                  disabled={isCheckingOut}
                  className="btn-primary text-sm px-6 py-2.5 flex items-center gap-2"
                >
                  {isCheckingOut ? (
                    <>
                      <Loader2 size={15} className="animate-spin" />
                      Redirecting...
                    </>
                  ) : (
                    <>
                      Unlock & Download — €19
                    </>
                  )}
                </button>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}

            <ResumePreview resume={generatedResume} locked={true} />
          </div>
        )}
      </div>
    </div>
  );
}
