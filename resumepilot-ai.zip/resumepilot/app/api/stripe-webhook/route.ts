import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { sendResumeEmail } from '@/lib/email';
import { generateResumeHTML } from '@/lib/pdfGenerator';
import { GeneratedResume } from '@/lib/types';
import Stripe from 'stripe';

export const runtime = 'nodejs';

// Use raw body for Stripe webhook verification
export async function POST(request: NextRequest) {
  const body = await request.text();
  const sig = request.headers.get('stripe-signature')!;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return NextResponse.json(
      { error: 'Invalid webhook signature' },
      { status: 400 }
    );
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;

    if (session.payment_status === 'paid') {
      try {
        const customerEmail = session.customer_email || '';
        const resumeDataStr = session.metadata?.resumeData;

        if (!resumeDataStr || !customerEmail) {
          console.error('Missing resume data or email in session metadata');
          return NextResponse.json({ received: true });
        }

        // Parse stored resume data
        let resumeData: GeneratedResume;
        try {
          resumeData = JSON.parse(resumeDataStr);
        } catch {
          console.error('Failed to parse resume data from metadata');
          return NextResponse.json({ received: true });
        }

        // Generate the resume HTML
        const resumeHTML = generateResumeHTML(resumeData);

        // For production: use Puppeteer to generate actual PDF
        // For this implementation, we send the HTML as a placeholder
        // In production, replace with actual PDF generation
        const htmlBuffer = Buffer.from(resumeHTML, 'utf-8');

        await sendResumeEmail({
          to: customerEmail,
          name: resumeData.fullName,
          pdfBuffer: htmlBuffer, // Replace with actual PDF buffer in production
        });

        console.log(`Resume emailed successfully to ${customerEmail}`);
      } catch (error) {
        console.error('Error processing successful payment:', error);
      }
    }
  }

  return NextResponse.json({ received: true });
}
