import { NextRequest, NextResponse } from 'next/server';
import { generateResume } from '@/lib/openai';
import { ResumeFormData } from '@/lib/types';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const formData = body as ResumeFormData;

    if (!formData.fullName || !formData.email || !formData.targetJobTitle) {
      return NextResponse.json(
        { error: 'Missing required fields: fullName, email, targetJobTitle' },
        { status: 400 }
      );
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        { error: 'OpenAI API key not configured' },
        { status: 500 }
      );
    }

    const generatedResume = await generateResume(formData);

    return NextResponse.json({ resume: generatedResume }, { status: 200 });
  } catch (error) {
    console.error('Error generating resume:', error);

    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: 'Failed to parse AI response. Please try again.' },
        { status: 500 }
      );
    }

    return NextResponse.json(
      {
        error: 'Failed to generate resume. Please try again.',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
