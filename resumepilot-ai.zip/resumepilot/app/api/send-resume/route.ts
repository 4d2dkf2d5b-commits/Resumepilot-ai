import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
import { generateResumeHTML } from '@/lib/pdfGenerator';
import { GeneratedResume } from '@/lib/types';

export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, resumeData } = body as {
      sessionId: string;
      resumeData: GeneratedResume;
    };

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID is required' },
        { status: 400 }
      );
    }

    // Verify payment with Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (session.payment_status !== 'paid') {
      return NextResponse.json(
        { error: 'Payment not completed' },
        { status: 403 }
      );
    }

    // Generate the resume HTML
    const resumeHTML = generateResumeHTML(resumeData);

    return NextResponse.json({
      success: true,
      resumeHTML,
      customerEmail: session.customer_email,
    });
  } catch (error) {
    console.error('Error processing resume download:', error);
    return NextResponse.json(
      { error: 'Failed to generate download. Please contact support.' },
      { status: 500 }
    );
  }
}
