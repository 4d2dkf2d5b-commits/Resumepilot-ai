'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle, Download, Loader2, Mail } from 'lucide-react';
import { GeneratedResume } from '@/lib/types';

function SuccessContent() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [resumeHTML, setResumeHTML] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');

  useEffect(() => {
    if (!sessionId) {
      setStatus('error');
      return;
    }

    // Try to get resume data from sessionStorage (set before checkout)
    const storedResume = sessionStorage.getItem('resumeData');
    
    if (storedResume) {
      const resumeData: GeneratedResume = JSON.parse(storedResume);
      
      // Verify payment and get download
      fetch('/api/send-resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, resumeData }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setResumeHTML(data.resumeHTML);
            setCustomerEmail(data.customerEmail || '');
            setStatus('success');
            // Clear stored data
            sessionStorage.removeItem('resumeData');
          } else {
            setStatus('error');
          }
        })
        .catch(() => setStatus('error'));
    } else {
      // Payment verified but resume data not in session
      // Just show success state
      setStatus('success');
    }
  }, [sessionId]);

  const handleDownloadHTML = () => {
    if (!resumeHTML) return;
    const blob = new Blob([resumeHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'resume.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    if (!resumeHTML) return;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(resumeHTML);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-6">
      <div className="max-w-md w-full text-center">
        {status === 'loading' && (
          <div className="flex flex-col items-center gap-4">
            <Loader2 size={32} className="animate-spin text-ink-400" />
            <p className="text-ink-600">Verifying payment & preparing your resume...</p>
          </div>
        )}

        {status === 'success' && (
          <div className="animate-fade-up">
            <div className="w-16 h-16 bg-ink-950 flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={28} className="text-white" />
            </div>

            <h1 className="text-2xl font-bold text-ink-950 mb-2">
              Payment successful!
            </h1>
            <p className="text-ink-500 mb-8 leading-relaxed">
              {customerEmail
                ? `Your resume has been emailed to ${customerEmail}.`
                : 'Your resume is ready to download.'}
            </p>

            {resumeHTML ? (
              <div className="space-y-3 mb-8">
                <button
                  onClick={handlePrint}
                  className="btn-primary w-full py-4 gap-2"
                >
                  <Download size={16} />
                  Download as PDF (Print to Save)
                </button>
                <button
                  onClick={handleDownloadHTML}
                  className="btn-secondary w-full py-4 gap-2"
                >
                  Download HTML Version
                </button>
              </div>
            ) : (
              <div className="bg-ink-50 border border-ink-200 p-4 mb-8 flex items-start gap-3 text-left">
                <Mail size={18} className="text-ink-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-ink-600">
                  Your resume has been sent to your email. Check your inbox
                  (and spam folder) for the PDF and Word attachments.
                </p>
              </div>
            )}

            <div className="border-t border-ink-100 pt-6 space-y-3">
              <p className="text-xs text-ink-400">Need help? Email us at support@resumepilot.ai</p>
              <Link href="/" className="btn-ghost text-sm">
                ← Back to home
              </Link>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div>
            <div className="w-16 h-16 bg-red-50 border border-red-200 flex items-center justify-center mx-auto mb-6">
              <span className="text-2xl">!</span>
            </div>
            <h1 className="text-xl font-bold text-ink-950 mb-2">
              Something went wrong
            </h1>
            <p className="text-ink-500 mb-6 text-sm">
              If you completed payment, your resume will be emailed to you
              within a few minutes. If not, please try again.
            </p>
            <div className="space-y-3">
              <Link href="/builder" className="btn-primary block text-center py-3">
                Try Again
              </Link>
              <Link href="/" className="btn-ghost text-sm block">
                Back to home
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 size={32} className="animate-spin text-ink-400" />
      </div>
    }>
      <SuccessContent />
    </Suspense>
  );
}
