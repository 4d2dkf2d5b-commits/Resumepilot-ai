import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'ResumePilot AI — ATS-Friendly Resume Builder in 2 Minutes',
  description:
    'Generate a recruiter-ready, ATS-optimized resume with AI in under 2 minutes. No design skills required. Download as PDF or Word.',
  keywords: [
    'AI Resume Builder',
    'ATS Resume',
    'Professional CV Builder',
    'Resume Generator',
    'ATS Optimized Resume',
    'AI CV Creator',
    'Free Resume Builder',
    'Professional Resume',
  ],
  authors: [{ name: 'ResumePilot AI' }],
  openGraph: {
    title: 'ResumePilot AI — ATS-Friendly Resume Builder',
    description:
      'Create a professional, recruiter-ready resume with AI in 2 minutes.',
    url: 'https://resumepilot.ai',
    siteName: 'ResumePilot AI',
    type: 'website',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'ResumePilot AI — AI Resume Builder',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ResumePilot AI — ATS-Friendly Resume Builder',
    description: 'Create a professional resume with AI in 2 minutes.',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: 'https://resumepilot.ai',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </head>
      <body className="bg-white text-ink-900 antialiased">{children}</body>
    </html>
  );
}
