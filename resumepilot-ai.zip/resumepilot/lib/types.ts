export interface WorkExperience {
  company: string;
  title: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

export interface Education {
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: string;
}

export interface Certification {
  name: string;
  issuer: string;
  year: string;
}

export interface ResumeFormData {
  // Personal Info
  fullName: string;
  email: string;
  phone: string;
  address: string;
  linkedIn?: string;
  website?: string;

  // Professional
  targetJobTitle: string;
  professionalSummary: string;

  // Experience
  workExperience: WorkExperience[];

  // Education
  education: Education[];

  // Skills & More
  skills: string;
  languages: string;
  certifications: Certification[];
}

export interface GeneratedResume {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  linkedIn?: string;
  website?: string;
  targetJobTitle: string;
  professionalSummary: string;
  workExperience: {
    company: string;
    title: string;
    startDate: string;
    endDate: string;
    current: boolean;
    bullets: string[];
  }[];
  education: {
    institution: string;
    degree: string;
    field: string;
    startDate: string;
    endDate: string;
    gpa?: string;
  }[];
  skills: string[];
  languages: string[];
  certifications: {
    name: string;
    issuer: string;
    year: string;
  }[];
}
