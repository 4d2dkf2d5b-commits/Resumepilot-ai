import OpenAI from 'openai';
import { ResumeFormData, GeneratedResume } from './types';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const SYSTEM_PROMPT = `You are an expert resume writer with 15+ years of experience crafting ATS-optimized resumes for Fortune 500 companies. Your task is to rewrite and enhance resume content to:

1. Use strong action verbs (Led, Spearheaded, Delivered, Achieved, Optimized, etc.)
2. Quantify achievements wherever possible (e.g., "Increased revenue by 34%", "Managed team of 12")
3. Use modern, professional language that passes ATS systems
4. Remove fluff and passive voice
5. Tailor content to the target job title
6. Follow best practices for professional resume writing
7. Keep bullet points concise and impactful (1-2 lines each)
8. Write a compelling professional summary that highlights value proposition

Return ONLY valid JSON with NO markdown, NO code blocks, NO additional text. Start your response with { and end with }.`;

export async function generateResume(
  formData: ResumeFormData
): Promise<GeneratedResume> {
  const prompt = `Rewrite and enhance this resume content professionally. Target role: ${formData.targetJobTitle}.

Input data:
${JSON.stringify(formData, null, 2)}

Return a JSON object with EXACTLY this structure (no extra fields, no markdown):
{
  "fullName": "string",
  "email": "string",
  "phone": "string",
  "address": "string",
  "linkedIn": "string or empty string",
  "website": "string or empty string",
  "targetJobTitle": "string - professionally titled version",
  "professionalSummary": "string - 2-4 compelling sentences with strong language",
  "workExperience": [
    {
      "company": "string",
      "title": "string",
      "startDate": "string",
      "endDate": "string",
      "current": boolean,
      "bullets": ["string - action verb + achievement + metric if possible", "..."]
    }
  ],
  "education": [
    {
      "institution": "string",
      "degree": "string",
      "field": "string",
      "startDate": "string",
      "endDate": "string",
      "gpa": "string or empty string"
    }
  ],
  "skills": ["skill1", "skill2", "..."],
  "languages": ["language1 (proficiency)", "..."],
  "certifications": [
    {
      "name": "string",
      "issuer": "string",
      "year": "string"
    }
  ]
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: prompt },
    ],
    temperature: 0.3,
    max_tokens: 4000,
    response_format: { type: 'json_object' },
  });

  const content = response.choices[0].message.content;
  if (!content) throw new Error('No content from OpenAI');

  const generated = JSON.parse(content) as GeneratedResume;
  return generated;
}
