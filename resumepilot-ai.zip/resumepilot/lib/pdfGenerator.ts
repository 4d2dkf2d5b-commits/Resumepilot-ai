import { GeneratedResume } from './types';

export function generateResumeHTML(resume: GeneratedResume): string {
  const skillsList = resume.skills.join(' · ');
  const languagesList = resume.languages.join(' · ');

  const workHTML = resume.workExperience
    .map(
      (job) => `
    <div style="margin-bottom: 14px;">
      <div style="display: flex; justify-content: space-between; align-items: baseline;">
        <div>
          <span style="font-weight: 700; font-size: 11pt;">${job.title}</span>
          <span style="color: #444;"> — ${job.company}</span>
        </div>
        <span style="font-size: 10pt; color: #555; white-space: nowrap; margin-left: 12px;">
          ${job.startDate} – ${job.current ? 'Present' : job.endDate}
        </span>
      </div>
      <ul style="margin: 5px 0 0 0; padding-left: 18px;">
        ${job.bullets.map((b) => `<li style="margin-bottom: 3px; font-size: 10.5pt;">${b}</li>`).join('')}
      </ul>
    </div>
  `
    )
    .join('');

  const educationHTML = resume.education
    .map(
      (edu) => `
    <div style="margin-bottom: 10px;">
      <div style="display: flex; justify-content: space-between; align-items: baseline;">
        <div>
          <span style="font-weight: 700;">${edu.degree}${edu.field ? ` in ${edu.field}` : ''}</span>
          <span style="color: #444;"> — ${edu.institution}</span>
        </div>
        <span style="font-size: 10pt; color: #555; white-space: nowrap; margin-left: 12px;">
          ${edu.startDate} – ${edu.endDate}
        </span>
      </div>
      ${edu.gpa ? `<div style="font-size: 10pt; color: #555; margin-top: 2px;">GPA: ${edu.gpa}</div>` : ''}
    </div>
  `
    )
    .join('');

  const certsHTML =
    resume.certifications.length > 0
      ? `
    <div style="margin-bottom: 14px;">
      <h2 style="font-size: 9.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; border-bottom: 1.5px solid #1a1a1a; padding-bottom: 4px; margin-bottom: 8px; margin-top: 14px;">Certifications</h2>
      ${resume.certifications
        .map(
          (cert) => `
        <div style="margin-bottom: 6px; font-size: 10.5pt;">
          <strong>${cert.name}</strong>${cert.issuer ? ` — ${cert.issuer}` : ''}${cert.year ? ` (${cert.year})` : ''}
        </div>
      `
        )
        .join('')}
    </div>
  `
      : '';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Times New Roman', Georgia, serif;
      font-size: 11pt;
      line-height: 1.45;
      color: #1a1a1a;
      background: white;
      padding: 42px 50px;
      max-width: 816px;
    }
    h2 {
      font-size: 9.5pt;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      border-bottom: 1.5px solid #1a1a1a;
      padding-bottom: 4px;
      margin-bottom: 10px;
      margin-top: 16px;
    }
    ul { list-style: disc; }
    a { color: #1a1a1a; text-decoration: none; }
  </style>
</head>
<body>
  <!-- Header -->
  <div style="text-align: center; margin-bottom: 18px; border-bottom: 2px solid #1a1a1a; padding-bottom: 14px;">
    <h1 style="font-size: 22pt; font-weight: 700; letter-spacing: -0.02em; margin-bottom: 4px;">${resume.fullName}</h1>
    <div style="font-size: 11pt; font-weight: 600; color: #333; margin-bottom: 8px; font-family: Arial, sans-serif; letter-spacing: 0.05em; text-transform: uppercase; font-size: 9.5pt;">${resume.targetJobTitle}</div>
    <div style="font-size: 9.5pt; color: #555; font-family: Arial, sans-serif;">
      ${[
        resume.email,
        resume.phone,
        resume.address,
        resume.linkedIn,
        resume.website,
      ]
        .filter(Boolean)
        .join(' &nbsp;|&nbsp; ')}
    </div>
  </div>

  <!-- Summary -->
  ${
    resume.professionalSummary
      ? `
  <div style="margin-bottom: 4px;">
    <h2>Professional Summary</h2>
    <p style="font-size: 10.5pt; line-height: 1.5;">${resume.professionalSummary}</p>
  </div>
  `
      : ''
  }

  <!-- Experience -->
  ${
    resume.workExperience.length > 0
      ? `
  <div>
    <h2>Work Experience</h2>
    ${workHTML}
  </div>
  `
      : ''
  }

  <!-- Education -->
  ${
    resume.education.length > 0
      ? `
  <div>
    <h2>Education</h2>
    ${educationHTML}
  </div>
  `
      : ''
  }

  <!-- Skills -->
  ${
    resume.skills.length > 0
      ? `
  <div>
    <h2>Skills</h2>
    <p style="font-size: 10.5pt;">${skillsList}</p>
  </div>
  `
      : ''
  }

  <!-- Languages -->
  ${
    resume.languages.length > 0
      ? `
  <div>
    <h2>Languages</h2>
    <p style="font-size: 10.5pt;">${languagesList}</p>
  </div>
  `
      : ''
  }

  <!-- Certifications -->
  ${certsHTML}
</body>
</html>`;
}
