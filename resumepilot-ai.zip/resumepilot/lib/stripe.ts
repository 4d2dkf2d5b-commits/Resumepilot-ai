import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
  typescript: true,
});

export const RESUME_PRICE_EUR = 1900; // €19.00 in cents

export async function createCheckoutSession({
  resumeData,
  customerEmail,
  successUrl,
  cancelUrl,
}: {
  resumeData: string;
  customerEmail: string;
  successUrl: string;
  cancelUrl: string;
}) {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'eur',
          product_data: {
            name: 'ResumePilot AI — Professional Resume',
            description:
              'ATS-optimized resume. PDF + Word download. Emailed to you instantly.',
            images: ['https://resumepilot.ai/product-image.png'],
          },
          unit_amount: RESUME_PRICE_EUR,
        },
        quantity: 1,
      },
    ],
    mode: 'payment',
    success_url: successUrl,
    cancel_url: cancelUrl,
    customer_email: customerEmail,
    metadata: {
      resumeData: resumeData.substring(0, 500), // Stripe metadata limit
    },
    payment_intent_data: {
      metadata: {
        resumeData: resumeData.substring(0, 500),
        customerEmail,
      },
    },
    billing_address_collection: 'required',
    custom_text: {
      submit: {
        message:
          'Your resume will be emailed to you immediately after payment.',
      },
    },
  });

  return session;
}
