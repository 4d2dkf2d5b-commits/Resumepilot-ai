import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendResumeEmail({
  to,
  name,
  pdfBuffer,
  wordBuffer,
}: {
  to: string;
  name: string;
  pdfBuffer: Buffer;
  wordBuffer?: Buffer;
}) {
  const attachments: nodemailer.SendMailOptions['attachments'] = [
    {
      filename: `${name.replace(/\s+/g, '_')}_Resume.pdf`,
      content: pdfBuffer,
      contentType: 'application/pdf',
    },
  ];

  if (wordBuffer) {
    attachments.push({
      filename: `${name.replace(/\s+/g, '_')}_Resume.docx`,
      content: wordBuffer,
      contentType:
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    });
  }

  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'ResumePilot AI <noreply@resumepilot.ai>',
    to,
    subject: `Your Professional Resume is Ready — ResumePilot AI`,
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f9f9f9;font-family:system-ui,-apple-system,sans-serif;">
  <div style="max-width:560px;margin:40px auto;background:#fff;border:1px solid #e5e5e5;">
    <!-- Header -->
    <div style="background:#111;padding:32px 40px;">
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="color:#fff;font-size:20px;font-weight:700;letter-spacing:-0.02em;">ResumePilot AI</span>
      </div>
    </div>
    
    <!-- Body -->
    <div style="padding:40px;">
      <h1 style="margin:0 0 8px;font-size:22px;font-weight:700;color:#111;letter-spacing:-0.02em;">
        Your resume is ready, ${name.split(' ')[0]}!
      </h1>
      <p style="margin:0 0 24px;color:#555;font-size:15px;line-height:1.6;">
        Your AI-enhanced, ATS-optimized resume has been generated and attached to this email. 
        It's ready to submit to your dream employers.
      </p>
      
      <div style="background:#f5f5f5;border-left:3px solid #111;padding:16px 20px;margin-bottom:24px;">
        <p style="margin:0;font-size:13px;font-weight:600;color:#111;text-transform:uppercase;letter-spacing:0.1em;">What's attached</p>
        <ul style="margin:8px 0 0;padding-left:16px;color:#555;font-size:14px;line-height:1.8;">
          <li>PDF version (best for most applications)</li>
          <li>Word document (for easy editing)</li>
        </ul>
      </div>
      
      <div style="border:1px solid #e5e5e5;padding:16px 20px;margin-bottom:24px;">
        <p style="margin:0 0 8px;font-size:13px;font-weight:600;color:#111;text-transform:uppercase;letter-spacing:0.1em;">Pro tips</p>
        <ul style="margin:0;padding-left:16px;color:#555;font-size:14px;line-height:1.8;">
          <li>Tailor your resume for each application</li>
          <li>Submit as PDF unless a Word doc is requested</li>
          <li>Mirror keywords from each job description</li>
          <li>Keep it to 1 page if under 10 years experience</li>
        </ul>
      </div>
      
      <p style="color:#888;font-size:13px;line-height:1.6;margin:0;">
        Questions? Reply to this email and we'll help.
      </p>
    </div>
    
    <!-- Footer -->
    <div style="border-top:1px solid #e5e5e5;padding:20px 40px;background:#fafafa;">
      <p style="margin:0;color:#999;font-size:12px;">
        © ${new Date().getFullYear()} ResumePilot AI · You're receiving this because you purchased a resume.
      </p>
    </div>
  </div>
</body>
</html>
    `,
    attachments,
  });
}
