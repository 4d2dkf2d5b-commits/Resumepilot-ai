# ResumePilot AI

> ATS-Friendly AI Resume Builder — Create a professional resume in 2 minutes.

Built with **Next.js 14**, **Tailwind CSS**, **OpenAI GPT-4o**, and **Stripe**.

---

## Features

- 🤖 **GPT-4o powered** — Rewrites your experience with action verbs, quantified achievements, professional language
- ✅ **ATS-optimized** — Clean formatting that passes Applicant Tracking Systems
- 💳 **Stripe Checkout** — Secure one-time payment of €19
- 📧 **Email delivery** — Resume emailed to customer on payment
- 📄 **PDF + Word** — Dual format download
- 📱 **Mobile responsive** — Works on any device
- ⚡ **Vercel-ready** — Deploy in one click

---

## Quick Start

### 1. Clone and install

```bash
git clone https://github.com/yourrepo/resumepilot-ai.git
cd resumepilot-ai
npm install
```

### 2. Configure environment variables

```bash
cp .env.example .env.local
```

Fill in your `.env.local`:

```env
# OpenAI
OPENAI_API_KEY=sk-...

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# App URL
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...

# Email (SMTP — Gmail example)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password
EMAIL_FROM=ResumePilot AI <noreply@resumepilot.ai>
```

### 3. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Setup Guide

### OpenAI

1. Go to [platform.openai.com](https://platform.openai.com)
2. Create an API key
3. Add to `OPENAI_API_KEY`

Model used: `gpt-4o` (change in `lib/openai.ts` if needed)

### Stripe

1. Create a [Stripe](https://stripe.com) account
2. Get your test keys from the Dashboard
3. Create a webhook endpoint pointing to `https://yourdomain.com/api/stripe-webhook`
4. Select the event: `checkout.session.completed`
5. Copy the webhook secret to `STRIPE_WEBHOOK_SECRET`

#### Testing Stripe locally

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Forward webhooks to local
stripe listen --forward-to localhost:3000/api/stripe-webhook
```

Test card: `4242 4242 4242 4242` · Any future date · Any CVC

### Email (SMTP)

For Gmail:
1. Enable 2FA on your Google account
2. Create an App Password at myaccount.google.com/apppasswords
3. Use that as `SMTP_PASS`

For production, consider [Resend](https://resend.com) or [SendGrid](https://sendgrid.com).

---

## PDF Generation

The current implementation generates an HTML version of the resume that users can print-to-PDF in their browser.

For **server-side PDF generation**, integrate Puppeteer in `lib/pdfGenerator.ts`:

```typescript
import puppeteer from 'puppeteer';

export async function generatePDF(html: string): Promise<Buffer> {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  await page.setContent(html);
  const pdf = await page.pdf({
    format: 'A4',
    margin: { top: '20mm', bottom: '20mm', left: '18mm', right: '18mm' },
    printBackground: true,
  });
  await browser.close();
  return Buffer.from(pdf);
}
```

Note: Puppeteer requires a Chromium binary. On Vercel, use `@sparticuz/chromium` for serverless compatibility.

---

## Deployment to Vercel

### One-click deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourrepo/resumepilot-ai)

### Manual

```bash
npm i -g vercel
vercel --prod
```

Add all environment variables in the Vercel Dashboard under **Settings → Environment Variables**.

Update `NEXT_PUBLIC_APP_URL` to your production domain.

---

## Project Structure

```
resumepilot-ai/
├── app/
│   ├── layout.tsx          # Root layout + SEO metadata
│   ├── page.tsx            # Homepage
│   ├── globals.css         # Global styles
│   ├── sitemap.ts          # Dynamic sitemap
│   ├── builder/
│   │   └── page.tsx        # Resume builder form
│   ├── success/
│   │   └── page.tsx        # Post-payment success page
│   └── api/
│       ├── generate-resume/ # OpenAI resume generation
│       ├── create-checkout/ # Stripe checkout session
│       ├── stripe-webhook/  # Payment webhook handler
│       └── send-resume/     # Post-payment download
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx
│   │   └── Footer.tsx
│   ├── sections/
│   │   ├── HeroSection.tsx
│   │   ├── FeaturesSection.tsx
│   │   ├── HowItWorksSection.tsx
│   │   ├── TestimonialsSection.tsx
│   │   ├── PricingSection.tsx
│   │   ├── FAQSection.tsx
│   │   └── CTASection.tsx
│   └── resume/
│       ├── PersonalInfoStep.tsx
│       ├── ExperienceStep.tsx
│       ├── EducationStep.tsx
│       ├── SkillsStep.tsx
│       └── ResumePreview.tsx
├── lib/
│   ├── types.ts            # TypeScript types
│   ├── openai.ts           # OpenAI integration
│   ├── stripe.ts           # Stripe utilities
│   ├── email.ts            # Nodemailer email
│   └── pdfGenerator.ts     # Resume HTML generation
└── public/
    ├── favicon.svg
    └── robots.txt
```

---

## Customization

### Change pricing

Edit `lib/stripe.ts`:
```typescript
export const RESUME_PRICE_EUR = 1900; // €19.00 in cents
```

And `components/sections/PricingSection.tsx` to update displayed price.

### Change AI model

Edit `lib/openai.ts`:
```typescript
model: 'gpt-4o', // Change to 'gpt-4o-mini' for lower cost
```

### Change currency

Update `lib/stripe.ts`:
```typescript
currency: 'usd', // or 'gbp', 'eur', etc.
```

---

## License

MIT — use freely for commercial projects.
